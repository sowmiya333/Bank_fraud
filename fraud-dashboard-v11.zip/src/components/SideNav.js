import React from 'react';
import { NavLink } from 'react-router-dom';

export default function SideNav({collapsed, onToggle}){
  return (
    <aside className={'sidenav '+(collapsed? 'collapsed':'')}>
      <div className="sidenav-top">
        <div className="logo">🛡️</div>
        <button className="toggle-btn" onClick={onToggle}>{collapsed? '➡':'⬅'}</button>
      </div>
      <nav className="sidenav-nav">
        <NavLink to="/" end className={({isActive})=> isActive? 'active':' '}>Dashboard</NavLink>
        <NavLink to="/top-accounts" className={({isActive})=> isActive? 'active':' '}>Top Fraud Accounts</NavLink>
        <NavLink to="/top-merchants" className={({isActive})=> isActive? 'active':' '}>Top Fraud Merchants</NavLink>
        <NavLink to="/blacklist-accounts" className={({isActive})=> isActive? 'active':' '}>Blacklisted Accounts</NavLink>
        <NavLink to="/delete-blacklist" className={({isActive})=> isActive? 'active':' '}>Delete Blacklisted Account</NavLink>
        <NavLink to="/blacklist-merchants" className={({isActive})=> isActive? 'active':' '}>Blacklisted Merchants</NavLink>
        <NavLink to="/recent-frauds" className={({isActive})=> isActive? 'active':' '}>Recent Fraud Transactions</NavLink>
        <NavLink to="/upload" className={({isActive})=> isActive? 'active':' '}>Upload</NavLink>
      </nav>
      <div className="sidenav-footer">Fraud Detection</div>
    </aside>
  )
}