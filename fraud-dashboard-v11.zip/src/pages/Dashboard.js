import React, {useEffect, useState} from 'react';
import { getAllTransactions, getFraudTransactions, getTotalFraudAmount, getDailyFraudTotals } from '../services/api';
import StatsCard from '../components/StatsCard';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export default function Dashboard(){
  const [total, setTotal] = useState(0);
  const [frauds, setFrauds] = useState(0);
  const [fraudAmount, setFraudAmount] = useState(0);
  const [trends, setTrends] = useState([]);

  useEffect(()=>{ load(); }, []);

  async function load(){
    try{
      const [allRes, frRes, amtRes, trendsRes] = await Promise.all([getAllTransactions(), getFraudTransactions(), getTotalFraudAmount(), getDailyFraudTotals(7)]);
      setTotal(Array.isArray(allRes.data)? allRes.data.length : (allRes.data.count || 0));
      setFrauds(Array.isArray(frRes.data)? frRes.data.length : (frRes.data.count || 0));
      setFraudAmount(amtRes.data.total ?? amtRes.data);
      setTrends(trendsRes.data || []);
    }catch(e){ console.error(e); }
  }

  return (
    <div>
      <div className="stats-grid">
        <StatsCard title="Total Transactions" value={total} />
        <StatsCard title="Fraudulent Transactions" value={frauds} />
        <StatsCard title="Fraud %" value={ total? ((frauds/total)*100).toFixed(2)+'%':'0%' } />
        <StatsCard title="Total Fraud Amount" value={'₹'+Number(fraudAmount).toLocaleString()} />
      </div>

      <div className="chart-card">
        <h3>Daily Fraud Trends (7 days)</h3>
        <div style={{height:260}}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={trends}>
              <XAxis dataKey="date" stroke="#9aa7bf" />
              <YAxis stroke="#9aa7bf" />
              <Tooltip />
              <Line type="monotone" dataKey="fraudCount" stroke="#60a5fa" strokeWidth={3} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}