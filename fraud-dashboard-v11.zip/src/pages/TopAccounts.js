import React, {useEffect, useState} from 'react';
import { getTopFraudAccounts } from '../services/api';
import SimpleTable from '../components/SimpleTable';
export default function TopAccounts(){
  const [data, setData] = useState([]);
  useEffect(()=>{ getTopFraudAccounts().then(r=>setData(r.data)).catch(()=>{}); },[]);
  return (<div><h3>Top Fraud Accounts</h3><SimpleTable columns={['accountId','fraudCount','fraudAmount']} data={data} /></div>)
}