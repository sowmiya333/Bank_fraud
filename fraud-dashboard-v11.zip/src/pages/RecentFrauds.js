import React, {useEffect, useState} from 'react';
import { getFraudTransactions } from '../services/api';
import SimpleTable from '../components/SimpleTable';
export default function RecentFrauds(){ const [data,setData]=useState([]); useEffect(()=>{ getFraudTransactions().then(r=>setData(r.data)).catch(()=>{}); },[]); return (<div><h3>Recent Fraud Transactions</h3><SimpleTable columns={['transactionId','accountId','merchantId','amount','timestamp','reason']} data={data} /></div>) }