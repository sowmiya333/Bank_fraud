import React, {useState} from 'react';
import { uploadSingle, uploadCSV } from '../services/api';

export default function Upload(){
  const [mode, setMode] = useState('single');
  const [jsonText, setJsonText] = useState('');
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);

  async function handlePredict(){
    if(mode==='single'){
      try{
        const obj = JSON.parse(jsonText);
        const res = await uploadSingle(obj);
        setResult(res.data);
      }catch(e){ alert('Invalid JSON or server error'); }
    }else{
      if(!file) return alert('Select CSV');
      const fd = new FormData(); fd.append('file', file);
      try{
        const res = await uploadCSV(fd);
        const blob = res.data;
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a'); a.href = url; a.download = 'predictions.csv'; a.click();
        setResult({downloaded:true});
      }catch(e){ alert('CSV failed'); }
    }
  }

  return (
    <div>
      <div className="card">
        <div className="mode-row">
          <label><input type="radio" checked={mode==='single'} onChange={()=>setMode('single')} /> Single</label>
          <label><input type="radio" checked={mode==='csv'} onChange={()=>setMode('csv')} /> CSV</label>
        </div>

        {mode==='single' ? (
          <textarea value={jsonText} onChange={e=>setJsonText(e.target.value)} placeholder='Paste transaction JSON here' className="json-input" />
        ) : (
          <input type="file" accept=".csv" onChange={e=>setFile(e.target.files[0])} />
        )}

        <div style={{marginTop:12}}><button onClick={handlePredict} className="btn">Predict</button></div>
      </div>

      <div className="card" style={{marginTop:12}}>
        <h3>Result</h3>
        <pre>{result? JSON.stringify(result,null,2): 'No result yet'}</pre>
      </div>
    </div>
  )
}