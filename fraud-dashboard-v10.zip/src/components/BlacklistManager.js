import React, {useState} from 'react';
export default function BlacklistManager({accounts, merchants, onDelete}){
  const [id, setId] = useState('');
  return (
    <div className="blacklist-manager">
      <h4>Blacklisted Accounts</h4>
      <div className="blk-row">
        <input placeholder="account id to delete" value={id} onChange={e=>setId(e.target.value)} />
        <button onClick={()=>{ if(id){ onDelete(id); setId(''); } }} className="btn-small">Delete</button>
      </div>
      <div className="blk-summary">{accounts?.length ?? 0} accounts</div>
      <h4>Blacklisted Merchants</h4>
      <div className="blk-summary">{merchants?.length ?? 0} merchants</div>
    </div>
  )
}