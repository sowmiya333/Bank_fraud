import React from 'react';
import { Link, useLocation } from 'react-router-dom';
export default function Navbar(){
  const loc = useLocation();
  return (
    <nav className="navbar">
      <div className="brand">🕵️ <span>Fraud Dashboard</span></div>
      <div className="links">
        <Link className={loc.pathname==='/'?'active':''} to="/">Dashboard</Link>
        <Link className={loc.pathname==='/upload'?'active':''} to="/upload">Upload</Link>
      </div>
    </nav>
  );
}