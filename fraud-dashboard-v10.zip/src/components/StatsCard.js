import React from 'react';
export default function StatsCard({title, value, small}){
  return (
    <div className={"stat-card "+(small? 'small':'' )}>
      <div className="stat-title">{title}</div>
      <div className="stat-value">{value}</div>
    </div>
  )
}