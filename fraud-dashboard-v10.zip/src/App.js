import React, {useEffect, useState} from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import Upload from './pages/Upload';

export default function App(){
  const [loading, setLoading] = useState(true);
  useEffect(()=>{
    // simulated loader for nice entrance animation
    const t = setTimeout(()=> setLoading(false), 1000);
    return ()=> clearTimeout(t);
  },[]);

  return (
    <div className="app-root">
      {loading && (
        <div className="loader-overlay">
          <div className="loader-inner">
            <div className="glow-ring"></div>
            <div className="loader-text">Fraud Detection Dashboard</div>
            <div className="loader-sub">Loading — detecting anomalies...</div>
          </div>
        </div>
      )}
      <Navbar />
      <main className="container">
        <Routes>
          <Route path="/" element={<Dashboard/>} />
          <Route path="/upload" element={<Upload/>} />
        </Routes>
      </main>
    </div>
  );
}