import axios from 'axios';
const BASE = 'http://localhost:8080/api';

export const getAllTransactions = () => axios.get(`${BASE}/transactions`);
export const getFraudTransactions = () => axios.get(`${BASE}/transactions/frauds`);
export const getTotalFraudAmount = () => axios.get(`${BASE}/admin/analytics/total-fraud-amount`);
export const getDailyFraudTotals = (days=7) => axios.get(`${BASE}/admin/analytics/daily-fraud-totals?days=${days}`);
export const getTopFraudAccounts = () => axios.get(`${BASE}/admin/analytics/top-fraud-accounts`);
export const getTopFraudMerchants = () => axios.get(`${BASE}/admin/analytics/top-fraud-merchants`);
export const getBlacklistAccounts = () => axios.get(`${BASE}/admin/blacklist/accounts`);
export const getBlacklistMerchants = () => axios.get(`${BASE}/admin/blacklist/merchants`);
export const deleteBlacklistAccount = (accountId) => axios.delete(`${BASE}/admin/blacklist/account/${accountId}`);
export const uploadSingle = (tx) => axios.post(`${BASE}/transactions/upload`, tx);
export const uploadCSV = (formData) => axios.post(`${BASE}/transactions/upload-csv`, formData, { headers: {'Content-Type':'multipart/form-data'}, responseType:'blob' });
