# fraud-dashboard-v4

Dark bluish-black themed React frontend for Fraud Detection Dashboard (v4).

## Quick start

1. Unzip:
```bash
unzip fraud-dashboard-v4.zip -d fraud-dashboard-v4
cd fraud-dashboard-v4
```

2. Install:
```bash
npm install
```

3. Run:
```bash
npm start
```

Frontend expects backend at http://localhost:8080/api/dashboard with endpoints:
- GET /summary
- GET /fraud-users
- GET /trends
- POST /upload (multipart/form-data)
- POST /predict-batch (accepts JSON array for batch predictions)
- POST /predict (accepts single JSON transaction)

