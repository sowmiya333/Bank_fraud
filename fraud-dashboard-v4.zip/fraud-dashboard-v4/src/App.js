import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Upload from './pages/Upload';
import Navbar from './components/Navbar';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';

const darkTheme = createTheme({
  palette: {
    mode: 'dark',
    background: { default: '#071027', paper: '#071827' },
    primary: { main: '#60a5fa' },
    secondary: { main: '#f472b6' },
    text: { primary: '#e6eef8' }
  },
  typography: { fontFamily: "'Inter', sans-serif" }
});

function App(){
  return (
    <ThemeProvider theme={darkTheme}>
      <CssBaseline />
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/upload" element={<Upload/>} />
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  );
}

export default App;
