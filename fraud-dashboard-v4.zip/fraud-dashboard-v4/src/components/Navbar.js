import React from 'react';
import { AppBar, Toolbar, Typography, Button } from '@mui/material';
import { Link, useLocation } from 'react-router-dom';

export default function Navbar(){
  const loc = useLocation();
  return (
    <AppBar position="static" color="transparent" elevation={0} sx={{borderBottom:'1px solid rgba(255,255,255,0.04)'}}>
      <Toolbar sx={{display:'flex', justifyContent:'space-between'}}>
        <Typography variant="h6" sx={{color:'#60a5fa', fontWeight:700}}>🕵️ Fraud Dashboard</Typography>
        <div>
          <Button component={Link} to="/" color={loc.pathname==='/'?'primary':'inherit'}>Dashboard</Button>
          <Button component={Link} to="/upload" color={loc.pathname==='/upload'?'primary':'inherit'}>Upload</Button>
        </div>
      </Toolbar>
    </AppBar>
  );
}
