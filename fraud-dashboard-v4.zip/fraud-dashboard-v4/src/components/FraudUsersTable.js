import React, { useEffect, useState } from 'react';
import { getFraudUsers } from '../services/api';

export default function FraudUsersTable(){
  const [users, setUsers] = useState([]);
  useEffect(()=>{ getFraudUsers().then(res=>setUsers(res.data)).catch(console.error); }, []);
  return (
    <div>
      <h3 style={{marginTop:0}}>Frequent Fraud Users</h3>
      <table className="table">
        <thead>
          <tr><th>User ID</th><th>Fraud Count</th></tr>
        </thead>
        <tbody>
          {users.map((u,i)=>(
            <tr key={i}><td>{u.userId}</td><td>{u.fraudCount}</td></tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
