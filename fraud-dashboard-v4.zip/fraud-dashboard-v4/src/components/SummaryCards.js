import React, { useEffect, useState } from 'react';
import { getSummary } from '../services/api';

export default function SummaryCards(){
  const [summary, setSummary] = useState({ total:0, frauds:0, fraudRate:0 });
  useEffect(()=>{ getSummary().then(res=>setSummary(res.data)).catch(console.error); }, []);
  const items = [
    { label:'Total Transactions', value: summary.total, color:'#0ea5e9' },
    { label:'Fraudulent Transactions', value: summary.frauds, color:'#fb7185' },
    { label:'Fraud Rate (%)', value: summary.fraudRate, color:'#34d399' }
  ];
  return (
    <div className="summary-grid">
      {items.map(it=>(
        <div key={it.label} className="kpi" style={{background:`linear-gradient(135deg, ${it.color}, rgba(255,255,255,0.04))`}}>
          <div className="label">{it.label}</div>
          <div className="value">{it.value ?? 0}</div>
        </div>
      ))}
    </div>
  );
}
