import React from 'react';
import SummaryCards from '../components/SummaryCards';
import FraudTrendChart from '../components/FraudTrendChart';
import FraudUsersTable from '../components/FraudUsersTable';

export default function Home(){
  return (
    <div className="container">
      <div className="header">
        <div className="title">Dashboard</div>
      </div>

      <div style={{display:'grid', gridTemplateColumns:'2fr 1fr', gap:16}}>
        <div>
          <div className="card">
            <SummaryCards />
          </div>

          <div className="card" style={{marginTop:16}}>
            <FraudTrendChart />
          </div>
        </div>

        <div>
          <div className="card">
            <h3 style={{marginTop:0}}>Quick Actions</h3>
            <p style={{color:'var(--muted)'}}>Upload transactions or view recent activity.</p>
          </div>

          <div className="card" style={{marginTop:16}}>
            <FraudUsersTable />
          </div>
        </div>
      </div>
    </div>
  );
}
