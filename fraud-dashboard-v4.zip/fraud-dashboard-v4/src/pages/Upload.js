import React, { useState } from 'react';
import Papa from 'papaparse';
import { uploadTransactions, predictBatch, predictSingle } from '../services/api';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export default function Upload(){
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState([]);
  const [results, setResults] = useState([]);
  const [processing, setProcessing] = useState(false);

  // single transaction form state
  const [singleTx, setSingleTx] = useState({
    transactionId: '',
    userId: '',
    amount: '',
    merchant: '',
    location: ''
  });
  const [singleResult, setSingleResult] = useState(null);

  const handleSelect = (e) => {
    const f = e.target.files[0];
    setFile(f);
    if(!f){ setPreview([]); return; }
    const name = f.name.toLowerCase();
    if(name.endsWith('.csv')){
      Papa.parse(f, { header: true, skipEmptyLines: true, complete: (r) => setPreview(r.data) });
    } else {
      const reader = new FileReader();
      reader.onload = (ev) => {
        try {
          const json = JSON.parse(ev.target.result);
          if(Array.isArray(json)) setPreview(json);
          else setPreview([json]);
        } catch(err){
          setPreview([]);
        }
      };
      reader.readAsText(f);
    }
  };

  const handleUpload = async () => {
    if(!file){ toast.error('Select a file'); return; }
    const formData = new FormData();
    formData.append('file', file);
    try{
      await uploadTransactions(formData);
      toast.success('File uploaded to backend');
    }catch(e){
      console.error(e);
      toast.error('Upload failed');
    }
  };

  const handlePredictPreview = async () => {
    if(preview.length===0){ toast.error('No preview data to predict'); return; }
    setProcessing(true);
    try{
      const resp = await predictBatch(preview);
      setResults(resp.data);
      toast.success('Predictions received for preview');
    }catch(e){
      console.error(e);
      toast.error('Prediction failed');
    }finally{ setProcessing(false); }
  };

  const handleSinglePredict = async () => {
    // basic validation
    if(!singleTx.userId || !singleTx.amount){
      toast.error('Please fill required fields (userId, amount)');
      return;
    }
    setProcessing(true);
    try{
      const payload = {
        transactionId: singleTx.transactionId || `tx-${Date.now()}`,
        userId: singleTx.userId,
        amount: Number(singleTx.amount),
        merchant: singleTx.merchant,
        location: singleTx.location
      };
      const resp = await predictSingle(payload);
      setSingleResult(resp.data);
      toast.success('Single transaction predicted');
    }catch(e){
      console.error(e);
      toast.error('Prediction failed');
    }finally{ setProcessing(false); }
  };

  return (
    <div className="container">
      <div className="card">
        <h3 style={{marginTop:0}}>Upload Transaction Document</h3>
        <div style={{display:'flex', gap:12, alignItems:'center'}}>
          <input type="file" accept=".csv,.json,.txt" onChange={handleSelect} />
          <button onClick={handleUpload} className="btn">Upload to Backend</button>
          <button onClick={handlePredictPreview} className="btn" disabled={processing}>{processing?'Predicting...':'Predict (Preview)'}</button>
        </div>
        <p style={{color:'var(--muted)'}}>After upload, backend will process and save. You can also run predictions on the preview data and see results instantly.</p>
      </div>

      <div style={{marginTop:16}} className="card">
        <h3 style={{marginTop:0}}>Single Transaction (Form)</h3>
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12}}>
          <input placeholder="transactionId (optional)" value={singleTx.transactionId} onChange={e=>setSingleTx({...singleTx, transactionId:e.target.value})} />
          <input placeholder="userId" value={singleTx.userId} onChange={e=>setSingleTx({...singleTx, userId:e.target.value})} />
          <input placeholder="amount" type="number" value={singleTx.amount} onChange={e=>setSingleTx({...singleTx, amount:e.target.value})} />
          <input placeholder="merchant" value={singleTx.merchant} onChange={e=>setSingleTx({...singleTx, merchant:e.target.value})} />
          <input placeholder="location" value={singleTx.location} onChange={e=>setSingleTx({...singleTx, location:e.target.value})} />
        </div>
        <div style={{marginTop:12}}>
          <button onClick={handleSinglePredict} className="btn">{processing ? 'Predicting...' : 'Predict Single'}</button>
        </div>

        {singleResult && (
          <div style={{marginTop:12}}>
            <h4>Result</h4>
            <table className="table">
              <tbody>
                <tr><td>fraudScore</td><td>{typeof singleResult.fraud_score==='number' ? singleResult.fraud_score.toFixed(4) : singleResult.fraud_score}</td></tr>
                <tr><td>isFraud</td><td>{String(singleResult.is_fraud ?? singleResult.isFraud ?? false)}</td></tr>
                <tr><td>reason</td><td>{singleResult.reason ?? '-'}</td></tr>
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div style={{marginTop:16}} className="card">
        <h3 style={{marginTop:0}}>Preview</h3>
        {preview.length===0 ? <p style={{color:'var(--muted)'}}>No preview available</p> : (
          <div style={{overflow:'auto', maxHeight:240}}>
            <table className="table">
              <thead>
                <tr>{Object.keys(preview[0]).map((k)=>(<th key={k}>{k}</th>))}</tr>
              </thead>
              <tbody>
                {preview.map((row,idx)=>(
                  <tr key={idx}>
                    {Object.values(row).map((v,i)=>(<td key={i}>{String(v)}</td>))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div style={{marginTop:16}} className="card">
        <h3 style={{marginTop:0}}>Predictions (Preview)</h3>
        {results.length===0 ? <p style={{color:'var(--muted)'}}>No predictions yet</p> : (
          <div style={{overflow:'auto', maxHeight:240}}>
            <table className="table">
              <thead>
                <tr><th>transactionId</th><th>fraudScore</th><th>isFraud</th><th>reason</th></tr>
              </thead>
              <tbody>
                {results.map((r,idx)=>(
                  <tr key={idx}>
                    <td>{r.transactionId ?? r.transaction_id ?? '-'}</td>
                    <td>{typeof r.fraud_score==='number' ? r.fraud_score.toFixed(3) : r.fraud_score}</td>
                    <td>{String(r.is_fraud ?? r.isFraud ?? false)}</td>
                    <td>{r.reason ?? '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
}
