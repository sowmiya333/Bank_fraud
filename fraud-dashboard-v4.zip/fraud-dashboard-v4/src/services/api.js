import axios from 'axios';
const API_BASE_URL = "http://localhost:8080/api/dashboard";

export const getSummary = () => axios.get(`${API_BASE_URL}/summary`);
export const getFraudUsers = () => axios.get(`${API_BASE_URL}/fraud-users`);
export const getFraudTrends = () => axios.get(`${API_BASE_URL}/trends`);
export const uploadTransactions = (formData) =>
  axios.post(`${API_BASE_URL}/upload`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });

export const predictBatch = (jsonArray) =>
  axios.post(`${API_BASE_URL}/predict-batch`, jsonArray, {
    headers: { 'Content-Type': 'application/json' }
  });

export const predictSingle = (jsonObj) =>
  axios.post(`${API_BASE_URL}/predict`, jsonObj, {
    headers: { 'Content-Type': 'application/json' }
  });
