import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Dashboard from "./components/Dashboard";
import UploadTransaction from "./components/UploadTransaction";
import "./styles/App.css";

function App() {
  return (
    <Router>
      <div className="app-container">
        <nav className="navbar">
          <h2>Fraud Detection Dashboard</h2>
          <div className="nav-links">
            <Link to="/">Dashboard</Link>
            <Link to="/upload">Upload & Predict</Link>
          </div>
        </nav>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/upload" element={<UploadTransaction />} />
        </Routes>
      </div>
    </Router>
  );
}
export default App;
