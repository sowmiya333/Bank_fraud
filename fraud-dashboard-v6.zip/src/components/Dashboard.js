import React, { useEffect, useState } from "react";
import {
  getAllTransactions,
  getFraudTransactions,
  getTotalFraudAmount,
  getDailyFraudTotals,
  getTopFraudAccounts,
  getTopFraudMerchants,
  getBlacklistAccounts,
  getBlacklistMerchants,
} from "../api";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import "../styles/Dashboard.css";

function Dashboard() {
  const [summary, setSummary] = useState({ total: 0, fraud: 0, amount: 0, percent: 0 });
  const [fraudTrends, setFraudTrends] = useState([]);
  const [topAccounts, setTopAccounts] = useState([]);
  const [topMerchants, setTopMerchants] = useState([]);
  const [blacklist, setBlacklist] = useState({ accounts: 0, merchants: 0 });
  const [recentFrauds, setRecentFrauds] = useState([]);

  useEffect(() => {
    async function fetchData() {
      try {
        const [allTx, fraudTx, totalAmt, trends, accs, merchs, blAcc, blMerch] = await Promise.all([
          getAllTransactions(),
          getFraudTransactions(),
          getTotalFraudAmount(),
          getDailyFraudTotals(),
          getTopFraudAccounts(),
          getTopFraudMerchants(),
          getBlacklistAccounts(),
          getBlacklistMerchants(),
        ]);
        const total = allTx.data.length;
        const fraud = fraudTx.data.length;
        const percent = total ? ((fraud / total) * 100).toFixed(2) : 0;
        setSummary({ total, fraud, amount: totalAmt.data, percent });
        setFraudTrends(trends.data);
        setTopAccounts(accs.data);
        setTopMerchants(merchs.data);
        setBlacklist({ accounts: blAcc.data.length, merchants: blMerch.data.length });
        setRecentFrauds(fraudTx.data.slice(0, 10));
      } catch (err) {
        console.error(err);
      }
    }
    fetchData();
  }, []);

  return (
    <div className="dashboard">
      <div className="cards">
        <div className="card"><h3>Total Transactions</h3><p>{summary.total}</p></div>
        <div className="card"><h3>Fraud Transactions</h3><p>{summary.fraud}</p></div>
        <div className="card"><h3>Fraud %</h3><p>{summary.percent}%</p></div>
        <div className="card"><h3>Total Fraud Amount</h3><p>₹{summary.amount}</p></div>
        <div className="card"><h3>Blacklisted Accounts</h3><p>{blacklist.accounts}</p></div>
        <div className="card"><h3>Blacklisted Merchants</h3><p>{blacklist.merchants}</p></div>
      </div>

      <div className="chart-section">
        <h3>Daily Fraud Trends</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={fraudTrends}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" /><YAxis /><Tooltip />
            <Line type="monotone" dataKey="fraudCount" stroke="#00bfff" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="tables">
        <div className="table">
          <h3>Top Fraud Accounts</h3>
          <table><thead><tr><th>Account ID</th><th>Fraud Count</th><th>Total Amount</th></tr></thead>
          <tbody>{topAccounts.map(acc => <tr key={acc.accountId}><td>{acc.accountId}</td><td>{acc.fraudCount}</td><td>₹{acc.fraudAmount}</td></tr>)}</tbody></table>
        </div>
        <div className="table">
          <h3>Top Fraud Merchants</h3>
          <table><thead><tr><th>Merchant ID</th><th>Fraud Count</th><th>Total Amount</th></tr></thead>
          <tbody>{topMerchants.map(m => <tr key={m.merchantId}><td>{m.merchantId}</td><td>{m.fraudCount}</td><td>₹{m.fraudAmount}</td></tr>)}</tbody></table>
        </div>
      </div>

      <div className="recent">
        <h3>Recent Fraudulent Transactions</h3>
        <table><thead><tr><th>ID</th><th>Account</th><th>Merchant</th><th>Amount</th><th>Confidence</th><th>Reason</th></tr></thead>
        <tbody>{recentFrauds.map(tx => <tr key={tx.transactionId}><td>{tx.transactionId}</td><td>{tx.accountId}</td><td>{tx.merchantId}</td><td>₹{tx.amount}</td><td>{(tx.confidence*100).toFixed(1)}%</td><td>{tx.reason}</td></tr>)}</tbody></table>
      </div>
    </div>
  );
}
export default Dashboard;
