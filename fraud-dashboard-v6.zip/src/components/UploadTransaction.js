import React, { useState } from "react";
import { uploadSingleTransaction, uploadCSV } from "../api";
import "../styles/UploadTransaction.css";

function UploadTransaction() {
  const [mode, setMode] = useState("single");
  const [formData, setFormData] = useState({ accountId: "", merchantId: "", amount: "" });
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);

  const handleUpload = async () => {
    try {
      let res = mode === "single" ? await uploadSingleTransaction(formData) : await uploadCSV(file);
      setResult(res.data);
    } catch (err) {
      alert("Error uploading or predicting");
    }
  };

  return (
    <div className="upload-page">
      <h2>Upload Transactions for Prediction</h2>
      <div className="mode-selector">
        <label><input type="radio" value="single" checked={mode === "single"} onChange={() => setMode("single")} />Single Transaction</label>
        <label><input type="radio" value="batch" checked={mode === "batch"} onChange={() => setMode("batch")} />CSV Batch Upload</label>
      </div>
      {mode === "single" ? (
        <div className="form-section">
          <input type="text" placeholder="Account ID" value={formData.accountId} onChange={(e) => setFormData({ ...formData, accountId: e.target.value })} />
          <input type="text" placeholder="Merchant ID" value={formData.merchantId} onChange={(e) => setFormData({ ...formData, merchantId: e.target.value })} />
          <input type="number" placeholder="Amount" value={formData.amount} onChange={(e) => setFormData({ ...formData, amount: e.target.value })} />
        </div>
      ) : (
        <div className="file-upload"><input type="file" accept=".csv" onChange={(e) => setFile(e.target.files[0])} /></div>
      )}
      <button className="predict-btn" onClick={handleUpload}>Predict</button>
      {result && (
        <div className="result-section">
          <h3>Prediction Result</h3>
          {Array.isArray(result) ? (
            <table><thead><tr><th>ID</th><th>Account</th><th>Merchant</th><th>Amount</th><th>Fraud?</th></tr></thead>
            <tbody>{result.map((r) => <tr key={r.transactionId}><td>{r.transactionId}</td><td>{r.accountId}</td><td>{r.merchantId}</td><td>₹{r.amount}</td><td>{r.isFraud ? "Yes" : "No"}</td></tr>)}</tbody></table>
          ) : (<pre>{JSON.stringify(result, null, 2)}</pre>)}
        </div>
      )}
    </div>
  );
}
export default UploadTransaction;
