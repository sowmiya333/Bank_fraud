import axios from "axios";
const API_BASE = "http://localhost:8080/api";

export const getAllTransactions = () => axios.get(`${API_BASE}/transactions`);
export const getFraudTransactions = () => axios.get(`${API_BASE}/transactions/frauds`);
export const getTotalFraudAmount = () => axios.get(`${API_BASE}/admin/analytics/total-fraud-amount`);
export const getDailyFraudTotals = () => axios.get(`${API_BASE}/admin/analytics/daily-fraud-totals`);
export const getTopFraudAccounts = () => axios.get(`${API_BASE}/admin/analytics/top-fraud-accounts`);
export const getTopFraudMerchants = () => axios.get(`${API_BASE}/admin/analytics/top-fraud-merchants`);
export const getBlacklistAccounts = () => axios.get(`${API_BASE}/admin/blacklist/accounts`);
export const getBlacklistMerchants = () => axios.get(`${API_BASE}/admin/blacklist/merchants`);

export const uploadSingleTransaction = (data) => axios.post(`${API_BASE}/transactions/upload`, data);
export const uploadCSV = (file) => {
  const formData = new FormData();
  formData.append("file", file);
  return axios.post(`${API_BASE}/transactions/upload-csv`, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};
