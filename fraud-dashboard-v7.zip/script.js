/*
  script.js
  Handles dashboard API calls and upload/predict flows.
  Assumes backend at http://localhost:8080 with endpoints:
    GET  /api/transactions
    GET  /api/transactions/frauds
    GET  /api/admin/analytics/total-fraud-amount
    GET  /api/admin/analytics/top-fraud-accounts
    GET  /api/admin/analytics/top-fraud-merchants
    GET  /api/admin/analytics/daily-fraud-totals?days=7
    GET  /api/admin/blacklist/accounts
    GET  /api/admin/blacklist/merchants
    POST /api/transactions/upload   (single JSON -> returns scored TransactionRecord)
    POST /api/transactions/upload-csv (multipart form 'file' -> returns CSV attachment)
    POST /api/transactions/score   (alias for immediate scoring)
*/

const BASE = 'http://localhost:8080';

// ---------------- DASHBOARD ----------------
async function fetchJson(path){ const res = await fetch(BASE + path); if(!res.ok) throw new Error(res.statusText); return res.json(); }

async function loadDashboard(){
  try{
    const [allTx, fraudTx, fraudAmount, topAcc, topMerch, trends, blAcc, blMerch] = await Promise.all([
      fetchJson('/api/transactions'),
      fetchJson('/api/transactions/frauds'),
      fetchJson('/api/admin/analytics/total-fraud-amount'),
      fetchJson('/api/admin/analytics/top-fraud-accounts'),
      fetchJson('/api/admin/analytics/top-fraud-merchants'),
      fetchJson('/api/admin/analytics/daily-fraud-totals?days=7'),
      fetchJson('/api/admin/blacklist/accounts'),
      fetchJson('/api/admin/blacklist/merchants')
    ]);

    const total = Array.isArray(allTx) ? allTx.length : (allTx.count || 0);
    const fraudCount = Array.isArray(fraudTx) ? fraudTx.length : (fraudTx.count || 0);
    const percent = total ? ((fraudCount/total)*100).toFixed(2) : '0.00';

    document.getElementById('total-transactions').innerText = total;
    document.getElementById('fraud-transactions').innerText = fraudCount;
    document.getElementById('fraud-percent').innerText = percent + '%';
    document.getElementById('fraud-amount').innerText = (typeof fraudAmount === 'number') ? '₹' + fraudAmount.toLocaleString() : fraudAmount;

    // trends chart
    renderTrendChart(trends);

    // top accounts
    fillTable('top-accounts-table', topAcc, ['accountId','fraudCount','fraudAmount']);

    // top merchants
    fillTable('top-merchants-table', topMerch, ['merchantId','fraudCount','fraudAmount']);

    // blacklist
    fillTable('blacklist-accounts-table', blAcc, ['accountId']);
    fillTable('blacklist-merchants-table', blMerch, ['merchantId']);

    // recent frauds
    fillTable('recent-frauds-table', fraudTx, ['transactionId','accountId','merchantId','amount','confidence','reason']);

  }catch(err){
    console.error('Dashboard load error', err);
  }
}

function fillTable(tableId, data, fields){
  const tbody = document.querySelector('#' + tableId + ' tbody');
  tbody.innerHTML = '';
  if(!Array.isArray(data) || data.length===0){ tbody.innerHTML = '<tr><td colspan="'+fields.length+'">No data</td></tr>'; return; }
  for(const row of data){
    const tr = document.createElement('tr');
    for(const f of fields){
      const td = document.createElement('td');
      let v = row[f];
      if(v === undefined && row[f.toLowerCase()]) v = row[f.toLowerCase()];
      td.innerText = (v === null || v === undefined) ? '-' : v;
      tr.appendChild(td);
    }
    tbody.appendChild(tr);
  }
}

let trendChartInstance = null;
function renderTrendChart(data){
  // data expected [{ _id: '2025-10-10', frauds: 5 } ] or [{date:'2025-10-10', fraudCount:5}]
  if(!Array.isArray(data)) data = [];
  const labels = data.map(d => d.date || d._id || '');
  const values = data.map(d => d.fraudCount || d.frauds || d.count || 0);
  const ctx = document.getElementById('trendChart').getContext('2d');
  if(trendChartInstance) trendChartInstance.destroy();
  trendChartInstance = new Chart(ctx, {
    type: 'line',
    data: { labels, datasets: [{ label:'Fraud count', data: values, borderColor:'#60a5fa', backgroundColor:'rgba(96,165,250,0.08)', tension:0.3, fill:true }] },
    options: { responsive:true, scales:{ y:{ beginAtZero:true } } }
  });
}

// ---------------- UPLOAD & PREDICT ----------------
document.addEventListener('DOMContentLoaded', ()=>{
  // dashboard load when index page
  if(document.getElementById('total-transactions')){
    loadDashboard();
  }

  // upload page logic
  const modeRadios = document.getElementsByName('mode');
  const singleForm = document.getElementById('single-form');
  const csvSection = document.getElementById('csv-section');
  const predictBtn = document.getElementById('predictBtn');
  const resultCard = document.getElementById('resultCard');
  const resultArea = document.getElementById('resultArea');
  const downloadLink = document.getElementById('downloadLink');
  const csvFileInput = document.getElementById('csvFile');
  const txForm = document.getElementById('txForm');

  if(modeRadios && predictBtn){
    function updateMode(){
      const mode = Array.from(modeRadios).find(r=>r.checked).value;
      if(mode === 'single'){ singleForm.style.display='block'; csvSection.style.display='none'; }
      else { singleForm.style.display='none'; csvSection.style.display='block'; }
      resultCard.style.display='none'; resultArea.innerHTML=''; downloadLink.style.display='none';
    }
    modeRadios.forEach(r => r.addEventListener('change', updateMode));
    updateMode();

    predictBtn.addEventListener('click', async ()=>{
      const mode = Array.from(modeRadios).find(r=>r.checked).value;
      resultCard.style.display='none'; resultArea.innerHTML=''; downloadLink.style.display='none';
      if(mode === 'single'){
        // collect form data
        const formData = new FormData(txForm);
        const obj = {};
        formData.forEach((v,k) => { obj[k] = v; });
        // type conversions
        if(obj.amount) obj.amount = parseFloat(obj.amount);
        if(!obj.transactionId) obj.transactionId = 'tx_' + Date.now();
        try{
          const res = await fetch(BASE + '/api/transactions/upload', { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify(obj) });
          if(!res.ok) throw new Error('Server Error');
          const data = await res.json();
          resultArea.innerHTML = '<pre>' + JSON.stringify(data, null, 2) + '</pre>';
          resultCard.style.display='block';
        }catch(err){ alert('Prediction failed: ' + err.message); }
      } else {
        // CSV mode
        const file = csvFileInput.files[0];
        if(!file){ alert('Select CSV file'); return; }
        const fd = new FormData();
        fd.append('file', file);
        try{
          const res = await fetch(BASE + '/api/transactions/upload-csv', { method:'POST', body: fd });
          if(!res.ok) throw new Error('Server Error: ' + res.status);
          // Expecting CSV attachment; try to read text and parse
          const blob = await res.blob();
          const text = await blob.text();
          // simple CSV parse (split lines)
          resultArea.innerHTML = '<pre>' + text.substring(0,2000) + (text.length>2000? '\n...':'') + '</pre>';
          // provide download link using blob
          const url = URL.createObjectURL(blob);
          downloadLink.href = url;
          downloadLink.style.display='inline-block';
          resultCard.style.display='block';
        }catch(err){ alert('Batch prediction failed: ' + err.message); }
      }
    });
  }
});
