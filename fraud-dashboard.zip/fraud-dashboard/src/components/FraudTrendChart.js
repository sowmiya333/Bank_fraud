import React, { useEffect, useState } from "react";
import { getFraudTrends } from "../services/api";
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from "recharts";
import { Paper, Typography } from "@mui/material";

export default function FraudTrendChart() {
  const [data, setData] = useState([]);

  useEffect(() => {
    getFraudTrends().then((res) => setData(res.data)).catch(console.error);
  }, []);

  return (
    <Paper style={{ marginTop: 20, padding: 20 }}>
      <Typography variant="h6">Fraud Trends Over Time</Typography>
      <div style={{ height: 300 }}>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="_id" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="frauds" stroke="#ff7300" strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Paper>
  );
}
