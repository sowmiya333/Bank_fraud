import React, { useEffect, useState } from "react";
import { Card, CardContent, Typography, Grid } from "@mui/material";
import { getSummary } from "../services/api";

export default function SummaryCards() {
  const [summary, setSummary] = useState({ total: 0, frauds: 0, fraudRate: 0 });

  useEffect(() => {
    getSummary().then((res) => setSummary(res.data)).catch(console.error);
  }, []);

  return (
    <Grid container spacing={2} style={{ marginTop: 16 }}>
      <Grid item xs={12} sm={4}>
        <Card>
          <CardContent>
            <Typography variant="h6">Total Transactions</Typography>
            <Typography variant="h4">{summary.total}</Typography>
          </CardContent>
        </Card>
      </Grid>

      <Grid item xs={12} sm={4}>
        <Card>
          <CardContent>
            <Typography variant="h6">Fraudulent Transactions</Typography>
            <Typography variant="h4" color="error">
              {summary.frauds}
            </Typography>
          </CardContent>
        </Card>
      </Grid>

      <Grid item xs={12} sm={4}>
        <Card>
          <CardContent>
            <Typography variant="h6">Fraud Rate</Typography>
            <Typography variant="h4">{summary.fraudRate}%</Typography>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );
}
