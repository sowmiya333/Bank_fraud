import React, { useEffect, useState } from "react";
import { getFraudUsers } from "../services/api";
import { Table, TableHead, TableBody, TableRow, TableCell, Paper, Typography } from "@mui/material";

export default function FraudUsersTable() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    getFraudUsers().then((res) => setUsers(res.data)).catch(console.error);
  }, []);

  return (
    <Paper style={{ marginTop: 20, padding: 20 }}>
      <Typography variant="h6" gutterBottom>
        Frequent Fraudulent Users
      </Typography>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>User ID</TableCell>
            <TableCell>Fraud Count</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {users.map((user, index) => (
            <TableRow key={index}>
              <TableCell>{user.userId}</TableCell>
              <TableCell>{user.fraudCount}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Paper>
  );
}
