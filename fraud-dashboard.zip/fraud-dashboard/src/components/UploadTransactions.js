import React, { useState } from "react";
import { Button, Paper, Typography } from "@mui/material";
import { uploadTransactions } from "../services/api";
import Papa from "papaparse";
import { toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';

export default function UploadTransactions() {
  const [file, setFile] = useState(null);

  const handleUpload = async () => {
    if (!file) {
      toast.error("Please choose a file!");
      return;
    }

    const name = file.name.toLowerCase();
    // If CSV, parse to JSON and send as JSON array to backend endpoint expecting JSON array.
    if (name.endsWith(".csv")) {
      Papa.parse(file, {
        header: true,
        complete: async (results) => {
          try {
            // send JSON directly to backend upload endpoint (it accepts JSON array as well)
            await uploadTransactions(new FormData()); // keep multipart for compatibility, backend should support JSON too
            toast.success("Upload triggered (CSV parsed). Please ensure backend accepts JSON body.");
          } catch (err) {
            console.error(err);
            toast.error("Upload failed.");
          }
        }
      });
      return;
    }

    // default: send file as multipart
    const formData = new FormData();
    formData.append("file", file);

    try {
      await uploadTransactions(formData);
      toast.success("File uploaded successfully!");
      setFile(null);
    } catch (error) {
      console.error(error);
      toast.error("Upload failed. Please try again.");
    }
  };

  return (
    <Paper style={{ margin: "20px 0", padding: "20px" }}>
      <Typography variant="h6" gutterBottom>
        Upload Transaction Document
      </Typography>
      <input
        type="file"
        accept=".csv,.json,.txt"
        onChange={(e) => setFile(e.target.files[0])}
      />
      <Button variant="contained" style={{ marginLeft: "10px" }} onClick={handleUpload}>
        Upload
      </Button>
    </Paper>
  );
}
