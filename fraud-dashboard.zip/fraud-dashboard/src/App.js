import React from "react";
import UploadTransactions from "./components/UploadTransactions";
import SummaryCards from "./components/SummaryCards";
import FraudUsersTable from "./components/FraudUsersTable";
import FraudTrendChart from "./components/FraudTrendChart";
import { Container, Typography } from "@mui/material";

function App() {
  return (
    <Container>
      <Typography variant="h4" align="center" gutterBottom style={{ margin: "20px 0" }}>
        Fraud Detection Dashboard
      </Typography>

      <UploadTransactions />
      <SummaryCards />
      <FraudTrendChart />
      <FraudUsersTable />
    </Container>
  );
}

export default App;
