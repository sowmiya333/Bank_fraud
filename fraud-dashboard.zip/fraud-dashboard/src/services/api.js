import axios from "axios";

// Base URL for your Spring Boot backend (dashboard API)
const API_BASE_URL = "http://localhost:8080/api/dashboard";

// Get summary of transactions and frauds
export const getSummary = () => axios.get(`${API_BASE_URL}/summary`);

// Get frequent fraudulent users
export const getFraudUsers = () => axios.get(`${API_BASE_URL}/fraud-users`);

// Get fraud trends over time
export const getFraudTrends = () => axios.get(`${API_BASE_URL}/trends`);

// Upload transaction file (multipart/form-data)
export const uploadTransactions = (formData) =>
  axios.post(`${API_BASE_URL}/upload`, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
