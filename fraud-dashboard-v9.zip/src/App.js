import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import Upload from './pages/Upload';

function App(){
  return (
    <div className="app">
      <Navbar />
      <div className="container">
        <Routes>
          <Route path="/" element={<Dashboard/>} />
          <Route path="/upload" element={<Upload/>} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
