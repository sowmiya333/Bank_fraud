import React, {useEffect, useState} from 'react';
import { getAllTransactions, getFraudTransactions, getTotalFraudAmount, getDailyFraudTotals, getTopFraudAccounts, getTopFraudMerchants, getBlacklistAccounts, getBlacklistMerchants, deleteBlacklistAccount } from '../services/api';
import StatsCard from '../components/StatsCard';
import SimpleTable from '../components/SimpleTable';
import BlacklistManager from '../components/BlacklistManager';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export default function Dashboard(){
  const [total, setTotal] = useState(0);
  const [frauds, setFrauds] = useState(0);
  const [fraudAmount, setFraudAmount] = useState(0);
  const [trends, setTrends] = useState([]);
  const [topAcc, setTopAcc] = useState([]);
  const [topMer, setTopMer] = useState([]);
  const [blkAcc, setBlkAcc] = useState([]);
  const [blkMer, setBlkMer] = useState([]);

  useEffect(()=>{ load(); }, []);

  async function load(){
    try{
      const [allRes, frRes, amtRes, trendsRes, accRes, merRes, blkAccRes, blkMerRes] = await Promise.all([
        getAllTransactions(), getFraudTransactions(), getTotalFraudAmount(), getDailyFraudTotals(7), getTopFraudAccounts(), getTopFraudMerchants(), getBlacklistAccounts(), getBlacklistMerchants()
      ]);
      setTotal(Array.isArray(allRes.data)? allRes.data.length : (allRes.data.count || 0));
      setFrauds(Array.isArray(frRes.data)? frRes.data.length : (frRes.data.count || 0));
      setFraudAmount(amtRes.data.total ?? amtRes.data);
      setTrends(trendsRes.data || []);
      setTopAcc(accRes.data || []);
      setTopMer(merRes.data || []);
      setBlkAcc(blkAccRes.data || []);
      setBlkMer(blkMerRes.data || []);
    }catch(e){ console.error(e); }
  }

  async function handleDelete(id){
    try{ await deleteBlacklistAccount(id); alert('Deleted '+id); load(); }catch(e){ alert('Delete failed'); }
  }

  return (
    <div>
      <div className="stats-grid">
        <StatsCard title="Total Transactions" value={total} />
        <StatsCard title="Fraudulent Transactions" value={frauds} />
        <StatsCard title="Fraud %" value={ total? ((frauds/total)*100).toFixed(2)+'%':'0%' } />
        <StatsCard title="Total Fraud Amount" value={'₹'+Number(fraudAmount).toLocaleString()} />
      </div>

      <div className="chart-card">
        <h3>Daily Fraud Trends (7 days)</h3>
        <div style={{height:260}}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={trends}>
              <XAxis dataKey="date" stroke="#9aa7bf" />
              <YAxis stroke="#9aa7bf" />
              <Tooltip />
              <Line type="monotone" dataKey="fraudCount" stroke="#60a5fa" strokeWidth={3} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="tables-grid">
        <div>
          <h3>Top Fraud Accounts</h3>
          <SimpleTable columns={['accountId','fraudCount','fraudAmount']} data={topAcc} />
        </div>
        <div>
          <h3>Top Fraud Merchants</h3>
          <SimpleTable columns={['merchantId','fraudCount','fraudAmount']} data={topMer} />
        </div>
      </div>

      <div className="grid-2">
        <BlacklistManager accounts={blkAcc} merchants={blkMer} onDelete={handleDelete} />
        <div>
          <h3>Recent Fraud Transactions</h3>
          <SimpleTable columns={['transactionId','accountId','merchantId','amount','confidence','reason']} data={[]} />
        </div>
      </div>
    </div>
  )
}