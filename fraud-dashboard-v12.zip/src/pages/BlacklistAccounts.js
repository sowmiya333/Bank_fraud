import React, {useEffect, useState} from 'react';
import { getBlacklistAccounts } from '../services/api';
import SimpleTable from '../components/SimpleTable';
export default function BlacklistAccounts(){
  const [data, setData] = useState([]);
  useEffect(()=>{ getBlacklistAccounts().then(r=>setData(r.data)).catch(()=>{}); },[]);
  return (<div><h3>Blacklisted Accounts</h3><SimpleTable columns={['accountId']} data={data} /></div>)
}