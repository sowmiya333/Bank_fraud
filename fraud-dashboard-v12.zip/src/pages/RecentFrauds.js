import React, {useEffect, useState} from 'react';
import { getFraudTransactions } from '../services/api';
import SimpleTable from '../components/SimpleTable';
export default function RecentFrauds(){ const [data,setData]=useState([]); useEffect(()=>{ (async ()=>{ const r = await getFraudTransactions(); setData(r.data || r); })(); },[]); return (<div><h3>Recent Fraud Transactions</h3><SimpleTable columns={['transactionId','accountId','merchantId','amount','timestamp','reason']} data={data} /></div>) }