import axios from 'axios';
const BASE = 'http://localhost:8080/api';
const mock = {
  transactions: [
    {transactionId:'tx_1001', accountId:'acct_1', merchantId:'shop_1', amount:12000, timestamp:'2025-10-10T09:30:00Z', reason:'suspicious pattern', fraud:true, confidence:0.92},
    {transactionId:'tx_1002', accountId:'acct_2', merchantId:'shop_2', amount:5000, timestamp:'2025-10-11T10:30:00Z', reason:'velocity', fraud:false, confidence:0.12}
  ],
  blacklist: { accounts: [{accountId:'acct_1', reason:'Multiple fraud attempts'}], merchants:[{merchantId:'shop_1', reason:'High fraud rate'}] },
  analytics: {
    totalFraudAmount: 340000,
    topAccounts: [{accountId:'acct_1', fraudCount:8, fraudAmount:120000}, {accountId:'acct_5', fraudCount:5, fraudAmount:50000}],
    topMerchants: [{merchantId:'shop_3', fraudCount:6, fraudAmount:90000}, {merchantId:'shop_1', fraudCount:4, fraudAmount:50000}],
    dailyTotals: [{date:'2025-10-10', fraudCount:3}, {date:'2025-10-11', fraudCount:4}]
  }
};

export const getAllTransactions = async ()=>{ try{ const r = await axios.get(`${BASE}/transactions`); return r; }catch(e){ return { data: mock.transactions }; } };
export const getFraudTransactions = async ()=>{ try{ const r = await axios.get(`${BASE}/transactions/frauds`); return r; }catch(e){ return { data: mock.transactions.filter(t=>t.fraud) }; } };
export const getTotalFraudAmount = async ()=>{ try{ const r = await axios.get(`${BASE}/admin/analytics/total-fraud-amount`); return r; }catch(e){ return { data: { total: mock.analytics.totalFraudAmount } }; } };
export const getDailyFraudTotals = async (days=7)=>{ try{ const r = await axios.get(`${BASE}/admin/analytics/daily-fraud-totals?days=${days}`); return r; }catch(e){ return { data: mock.analytics.dailyTotals }; } };
export const getTopFraudAccounts = async ()=>{ try{ const r = await axios.get(`${BASE}/admin/analytics/top-fraud-accounts`); return r; }catch(e){ return { data: mock.analytics.topAccounts }; } };
export const getTopFraudMerchants = async ()=>{ try{ const r = await axios.get(`${BASE}/admin/analytics/top-fraud-merchants`); return r; }catch(e){ return { data: mock.analytics.topMerchants }; } };
export const getBlacklistAccounts = async ()=>{ try{ const r = await axios.get(`${BASE}/admin/blacklist/accounts`); return r; }catch(e){ return { data: mock.blacklist.accounts }; } };
export const getBlacklistMerchants = async ()=>{ try{ const r = await axios.get(`${BASE}/admin/blacklist/merchants`); return r; }catch(e){ return { data: mock.blacklist.merchants }; } };
export const deleteBlacklistAccount = async (accountId)=>{ try{ const r = await axios.delete(`${BASE}/admin/blacklist/account/${accountId}`); return r; }catch(e){ return { data: { success:true, accountId } }; } };
export const uploadSingle = async (tx)=>{ try{ const r = await axios.post(`${BASE}/transactions/upload`, tx); return r; }catch(e){ const scored={...tx, fraud: Math.random()>0.7, confidence: +(Math.random()).toFixed(2)}; mock.transactions.push(scored); return { data: scored }; } };
export const uploadCSV = async (formData)=>{ try{ const r = await axios.post(`${BASE}/transactions/upload-csv`, formData, { headers:{'Content-Type':'multipart/form-data'}, responseType:'blob' }); return r; }catch(e){ const results = [{message:'mocked-csv', file:'pred.csv'}]; return { data: results }; } };
