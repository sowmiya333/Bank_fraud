import React, {useState, useEffect} from 'react';
import { Routes, Route } from 'react-router-dom';
import SideNav from './components/SideNav';
import Dashboard from './pages/Dashboard';
import TopAccounts from './pages/TopAccounts';
import TopMerchants from './pages/TopMerchants';
import BlacklistAccounts from './pages/BlacklistAccounts';
import DeleteBlacklist from './pages/DeleteBlacklist';
import BlacklistMerchants from './pages/BlacklistMerchants';
import RecentFrauds from './pages/RecentFrauds';
import Upload from './pages/Upload';

export default function App(){
  const [collapsed, setCollapsed] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(()=>{ const t=setTimeout(()=>setLoading(false),800); return ()=>clearTimeout(t); },[]);

  return (
    <div className={'app-root '+(collapsed? 'nav-collapsed':'')}>
      {loading && (
        <div className="loader-overlay"><div className="loader-inner"><div className="glow-ring"></div><div className="loader-text">Fraud Detection Dashboard</div><div className="loader-sub">Loading — detecting anomalies...</div></div></div>
      )}
      <SideNav collapsed={collapsed} onToggle={()=>setCollapsed(!collapsed)} />
      <div className="main-area">
        <header className="topbar">
          <div className="topbar-left">Fraud Detection Dashboard</div>
        </header>
        <main className="main-content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/top-accounts" element={<TopAccounts />} />
            <Route path="/top-merchants" element={<TopMerchants />} />
            <Route path="/blacklist-accounts" element={<BlacklistAccounts />} />
            <Route path="/delete-blacklist" element={<DeleteBlacklist />} />
            <Route path="/blacklist-merchants" element={<BlacklistMerchants />} />
            <Route path="/recent-frauds" element={<RecentFrauds />} />
            <Route path="/upload" element={<Upload />} />
          </Routes>
        </main>
      </div>
    </div>
  )
}
