# fraud-dashboard-v2

Dark themed React frontend for Fraud Detection Dashboard (Upload + Summary + Trends + Frequent Fraud Users)

## Quick start

1. Unzip the project:
```bash
unzip fraud-dashboard-v2.zip -d fraud-dashboard-v2
cd fraud-dashboard-v2
```

2. Install dependencies:
```bash
npm install
```

3. Start the app:
```bash
npm start
```

App will open at `http://localhost:3000`.

## Backend expectations

This frontend calls a backend at `http://localhost:8080/api/dashboard` with endpoints:
- `GET /summary` => returns { total, frauds, fraudRate, lastUpdated }
- `GET /fraud-users` => returns list of { userId, fraudCount }
- `GET /trends` => returns list of { _id: 'YYYY-MM-DD', frauds: number }
- `POST /upload` => accepts multipart/form-data with key 'file' OR JSON body with transactions array

Make sure your Spring Boot backend serves those endpoints or change `src/services/api.js`.

## Notes

- The upload component accepts CSV/JSON. CSV is not auto-parsed client-side for now; it sends file to backend.
- This project uses Material UI and Recharts for UI and charts.
