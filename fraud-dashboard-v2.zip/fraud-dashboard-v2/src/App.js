import React from "react";
import Dashboard from "./pages/Dashboard";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";

const darkTheme = createTheme({
  palette: {
    mode: 'dark',
    background: { default: '#0f1724', paper: '#111827' },
    primary: { main: '#60a5fa' },
    secondary: { main: '#f472b6' },
    text: { primary: '#e6eef8' }
  },
  typography: {
    fontFamily: "'Inter', sans-serif"
  }
});

function App() {
  return (
    <ThemeProvider theme={darkTheme}>
      <CssBaseline />
      <Dashboard />
    </ThemeProvider>
  );
}

export default App;
