import React from "react";
import UploadTransactions from "../components/UploadTransactions";
import SummaryCards from "../components/SummaryCards";
import FraudTrendChart from "../components/FraudTrendChart";
import FraudUsersTable from "../components/FraudUsersTable";

export default function Dashboard(){
  return (
    <div className="container">
      <div className="header">
        <div className="title">🕵️ Fraud Detection Dashboard</div>
      </div>

      <div style={{display:'grid', gridTemplateColumns:'2fr 1fr', gap:16}}>
        <div>
          <div className="card">
            <SummaryCards />
          </div>

          <div style={{marginTop:16}} className="card">
            <FraudTrendChart />
          </div>
        </div>

        <div>
          <div className="card">
            <UploadTransactions />
          </div>

          <div style={{marginTop:16}} className="card">
            <FraudUsersTable />
          </div>
        </div>
      </div>
    </div>
  );
}
