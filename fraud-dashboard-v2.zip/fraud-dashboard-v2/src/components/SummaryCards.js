import React, { useEffect, useState } from "react";
import { getSummary } from "../services/api";

export default function SummaryCards(){
  const [summary, setSummary] = useState({ total:0, frauds:0, fraudRate:0 });
  useEffect(()=>{ getSummary().then(res=>setSummary(res.data)).catch(console.error); }, []);

  const items = [
    { label: 'Total Transactions', value: summary.total, bg: 'linear-gradient(135deg,#0ea5e9,#2563eb)' },
    { label: 'Fraudulent Transactions', value: summary.frauds, bg: 'linear-gradient(135deg,#fb7185,#f97316)' },
    { label: 'Fraud Rate (%)', value: summary.fraudRate, bg: 'linear-gradient(135deg,#34d399,#059669)' }
  ];

  return (
    <div className="summary-grid">
      {items.map(it => (
        <div key={it.label} className="card kpi" style={{background:it.bg}}>
          <div className="label">{it.label}</div>
          <div className="value">{it.value ?? 0}</div>
        </div>
      ))}
    </div>
  );
}
