import React, { useState } from "react";
import { uploadTransactions } from "../services/api";
import { toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';

export default function UploadTransactions(){
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleUpload = async () => {
    if(!file){ toast.error("Select a file"); return; }
    setLoading(true);
    const formData = new FormData();
    formData.append("file", file);
    try{
      await uploadTransactions(formData);
      toast.success("Uploaded successfully");
      setFile(null);
    }catch(e){
      console.error(e);
      toast.error("Upload failed");
    }finally{ setLoading(false); }
  };

  return (
    <div>
      <h3 style={{marginTop:0}}>Upload Transactions</h3>
      <div className="upload-row">
        <input type="file" accept=".csv,.json,.txt" onChange={e=>setFile(e.target.files[0])} />
        <button onClick={handleUpload} style={{background:'#2563eb', color:'#fff', border:'none', padding:'10px 14px', borderRadius:8}}>
          {loading ? 'Uploading...' : 'Upload'}
        </button>
      </div>
      <p style={{color:'#9aa7bf', marginTop:8, fontSize:13}}>Upload a JSON array or CSV of transactions. Backend will process and return results.</p>
    </div>
  );
}
