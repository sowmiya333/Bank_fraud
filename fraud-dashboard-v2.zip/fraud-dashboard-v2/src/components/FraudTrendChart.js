import React, { useEffect, useState } from "react";
import { getFraudTrends } from "../services/api";
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from "recharts";

export default function FraudTrendChart(){
  const [data, setData] = useState([]);
  useEffect(()=>{ getFraudTrends().then(res=>setData(res.data)).catch(console.error); }, []);
  return (
    <div style={{height:320}}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)"/>
          <XAxis dataKey="_id" stroke="#9aa7bf"/>
          <YAxis stroke="#9aa7bf"/>
          <Tooltip wrapperStyle={{background:'#0b1220', border:'1px solid rgba(255,255,255,0.04)', color:'#e6eef8'}}/>
          <Line type="monotone" dataKey="frauds" stroke="#fb7185" strokeWidth={3} dot={{r:4}}/>
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
