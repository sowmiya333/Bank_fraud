import React, {useState} from 'react';
import '../styles/Upload.css';
import '../styles/Cards.css';
import { uploadSingle, uploadCSV } from '../services/api';

export default function Upload(){
  const [mode, setMode] = useState('single');
  const [form, setForm] = useState({
    transactionId:'', accountId:'', merchantId:'', merchantCategory:'', amount:'', currency:'INR',
    timestamp:'', deviceId:'', deviceIp:'', latitude:'', longitude:'', billingCountry:'', shippingCountry:''
  });
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  function onChange(e){ setForm({...form, [e.target.name]: e.target.value}); }

  async function handlePredict(){
    try{
      setLoading(true);
      setResult(null);
      if(mode==='single'){
        // send JSON body to backend
        const res = await uploadSingle(form);
        setResult(res.data);
      } else {
        if(!file){ setResult({error:'Please select a CSV file.'}); return; }
        const fd = new FormData();
        fd.append('file', file);
        // backend returns blob (csv) - download it
        const res = await uploadCSV(fd);
        const blob = new Blob([res.data], {type: 'text/csv'});
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'predictions.csv';
        a.click();
        window.URL.revokeObjectURL(url);
        setResult({downloaded: true});
      }
    }catch(err){
      setResult(err.response?.data || {error: 'Prediction failed'});
    }finally{ setLoading(false); }
  }

  return (
    <div className="page upload-page">
      <header className="page-header">
        <h1 className="page-title">Upload & Predict</h1>
        <div className="page-sub">Single transaction or CSV batch</div>
      </header>

      <div className="card form-card">
        <div className="mode-toggle">
          <button className={mode==='single'? 'active':''} onClick={()=>setMode('single')}>Single</button>
          <button className={mode==='csv'? 'active':''} onClick={()=>setMode('csv')}>CSV</button>
        </div>

        {mode==='single' ? (
          <div className="form-grid">
            <input name="transactionId" placeholder="Transaction ID" value={form.transactionId} onChange={onChange} />
            <input name="accountId" placeholder="Account ID" value={form.accountId} onChange={onChange} />
            <input name="merchantId" placeholder="Merchant ID" value={form.merchantId} onChange={onChange} />
            <input name="merchantCategory" placeholder="Merchant Category" value={form.merchantCategory} onChange={onChange} />
            <input name="amount" placeholder="Amount" value={form.amount} onChange={onChange} />
            <input name="currency" placeholder="Currency" value={form.currency} onChange={onChange} />
            <input name="timestamp" placeholder="Timestamp" value={form.timestamp} onChange={onChange} />
            <input name="deviceId" placeholder="Device ID" value={form.deviceId} onChange={onChange} />
            <input name="deviceIp" placeholder="Device IP" value={form.deviceIp} onChange={onChange} />
            <input name="latitude" placeholder="Latitude" value={form.latitude} onChange={onChange} />
            <input name="longitude" placeholder="Longitude" value={form.longitude} onChange={onChange} />
            <input name="billingCountry" placeholder="Billing Country" value={form.billingCountry} onChange={onChange} />
            <input name="shippingCountry" placeholder="Shipping Country" value={form.shippingCountry} onChange={onChange} />
          </div>
        ) : (
          <div className="upload-csv">
            <input type="file" accept=".csv" onChange={e=>setFile(e.target.files[0])} />
          </div>
        )}

        <div className="actions">
          <button className="btn primary" onClick={handlePredict} disabled={loading}>{loading? 'Working...':'Predict'}</button>
        </div>
      </div>

      <div className="card result-card">
        <h4>Result</h4>
        <pre className="result-pre">{result? JSON.stringify(result,null,2): 'No result yet'}</pre>
      </div>
    </div>
  )
}\n