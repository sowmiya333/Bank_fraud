import React, {useEffect, useState} from 'react';
import '../styles/Dashboard.css';
import '../styles/Cards.css';
import { getTotalFraudAmount, getDailyFraudTotals } from '../services/api';

export default function Dashboard(){
  const [total, setTotal] = useState(null);
  const [daily, setDaily] = useState([]);

  useEffect(()=>{
    getTotalFraudAmount().then(r=>setTotal(r.data)).catch(()=>{});
    getDailyFraudTotals(7).then(r=>setDaily(r.data)).catch(()=>{});
  },[]);

  return (
    <div className="page dashboard-page">
      <header className="page-header">
        <h1 className="page-title">Fraud Detection Dashboard</h1>
        <div className="page-sub">Overview and analytics</div>
      </header>

      <section className="stats-grid">
        <div className="card stat-card">
          <h3 className="stat-label">Total Fraud Amount</h3>
          <div className="stat-value">{total !== null ? total : 'Loading...'}</div>
        </div>

        <div className="card stat-card">
          <h3 className="stat-label">Last 7 days - Frauds</h3>
          <div className="stat-value">{daily.length? daily.map(d=>d.count).join(' · '): 'Loading...'}</div>
        </div>

      </section>

      <section className="content-area">
        <div className="card">
          <h3>Recent analytics</h3>
          <p className="muted">Charts and deeper visualization can go here.</p>
        </div>
      </section>
    </div>
  )
}\n