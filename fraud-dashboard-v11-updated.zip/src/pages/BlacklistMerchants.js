import React, {useEffect, useState} from 'react';
import { getBlacklistMerchants } from '../services/api';
import SimpleTable from '../components/SimpleTable';
export default function BlacklistMerchants(){ const [data,setData]=useState([]); useEffect(()=>{ getBlacklistMerchants().then(r=>setData(r.data)).catch(()=>{}); },[]); return (<div><h3>Blacklisted Merchants</h3><SimpleTable columns={['merchantId']} data={data} /></div>) }