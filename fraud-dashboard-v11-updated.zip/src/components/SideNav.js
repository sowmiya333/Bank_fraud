import React from 'react';
import { NavLink } from 'react-router-dom';
import '../styles/SideNav.css';

export default function SideNav({collapsed, onToggle}){
  const links = [
    {to: '/', label: 'Dashboard'},
    {to: '/top-accounts', label: 'Top Fraud Accounts'},
    {to: '/top-merchants', label: 'Top Fraud Merchants'},
    {to: '/blacklist-accounts', label: 'Blacklisted Accounts'},
    {to: '/delete-blacklist', label: 'Delete Blacklisted Account'},
    {to: '/blacklist-merchants', label: 'Blacklisted Merchants'},
    {to: '/recent-frauds', label: 'Recent Fraud Transactions'},
    {to: '/upload', label: 'Upload'},
  ];

  return (
    <aside className={'sidenav '+(collapsed? 'collapsed':'')} aria-expanded={!collapsed}>
      <div className="sidenav-top">
        <div className="logo" title="Fraud Detection">FD</div>
        <button className="toggle-btn" onClick={onToggle} aria-label={collapsed? 'Expand sidebar':'Collapse sidebar'}>
          <span className="hamburger">☰</span>
        </button>
      </div>

      <nav className="sidenav-nav" role="navigation" aria-label="Main">
        {links.map((l) => (
          <NavLink key={l.to} to={l.to} end className={({isActive})=> 'snav-link '+(isActive? 'active':'')} title={collapsed? l.label: ''}>
            <span className="snav-icon">●</span>
            <span className="snav-text">{l.label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="sidenav-footer">{!collapsed && 'Fraud Detection'}</div>
    </aside>
  )
}\n