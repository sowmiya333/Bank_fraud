import React from 'react';
export default function SimpleTable({columns, data}){
  return (
    <div className="table-wrap">
      <table>
        <thead><tr>{columns.map(c=>(<th key={c}>{c}</th>))}</tr></thead>
        <tbody>
          {data && data.length>0 ? data.map((r,i)=>(<tr key={i}>{columns.map(c=>(<td key={c}>{r[c] ?? r[c.toLowerCase()] ?? '-'}</td>))}</tr>)) : <tr><td colSpan={columns.length}>No data</td></tr>}
        </tbody>
      </table>
    </div>
  )
}