import React, {useState} from 'react';
import { deleteBlacklistAccount } from '../services/api';
export default function DeleteBlacklist(){
  const [id, setId] = useState('');
  async function handleDelete(){
    if(!id) return alert('Enter account id');
    if(!window.confirm('Delete blacklisted account '+id+' ?')) return;
    try{ await deleteBlacklistAccount(id); alert('Deleted '+id); setId(''); }catch(e){ alert('Delete failed'); }
  }
  return (
    <div>
      <h3>Delete Blacklisted Account</h3>
      <div className="card">
        <input placeholder="Account ID" value={id} onChange={e=>setId(e.target.value)} />
        <button onClick={handleDelete} className="btn" style={{marginLeft:8}}>Delete</button>
      </div>
    </div>
  )
}