import React, {useEffect, useState} from 'react';
import { getTopFraudMerchants } from '../services/api';
import SimpleTable from '../components/SimpleTable';
export default function TopMerchants(){
  const [data, setData] = useState([]);
  useEffect(()=>{ (async ()=>{ const r = await getTopFraudMerchants(); setData(r.data || r); })(); },[]);
  return (<div><h3>Top Fraud Merchants</h3><SimpleTable columns={['merchantId','fraudCount','fraudAmount']} data={data} /></div>)
}