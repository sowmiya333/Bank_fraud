import React, {useState} from 'react';
import { uploadSingle, uploadCSV } from '../services/api';

export default function Upload(){
  const [mode, setMode] = useState('single');
  const [form, setForm] = useState({
    transactionId:'', accountId:'', merchantId:'', merchantCategory:'', amount:'', currency:'INR',
    timestamp:'', deviceId:'', deviceIp:'', latitude:'', longitude:'', billingCountry:'', shippingCountry:'', metadata:''
  });
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);

  function onChange(e){ setForm({...form, [e.target.name]: e.target.value}); }

  async function handlePredict(){
    if(mode==='single'){
      if(!form.accountId || !form.amount) return alert('accountId and amount required');
      try{ const res = await uploadSingle({...form, amount: parseFloat(form.amount)}); setResult(res.data); }catch(e){ alert('Predict failed'); }
    }else{
      if(!file) return alert('Select CSV');
      const fd = new FormData(); fd.append('file', file);
      try{ const res = await uploadCSV(fd); const blob = res.data; const url = URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='predictions.csv'; a.click(); setResult({downloaded:true}); }catch(e){ alert('CSV failed'); }
    }
  }

  return (
    <div>
      <h3>Upload & Predict</h3>
      <div className="card">
        <div className="mode-row">
          <label><input type="radio" checked={mode==='single'} onChange={()=>setMode('single')} /> Single</label>
          <label style={{marginLeft:12}}><input type="radio" checked={mode==='csv'} onChange={()=>setMode('csv')} /> CSV</label>
        </div>

        {mode==='single' ? (
          <div className="form-grid">
            <input name="transactionId" placeholder="transactionId" value={form.transactionId} onChange={onChange} />
            <input name="accountId" placeholder="accountId *" value={form.accountId} onChange={onChange} />
            <input name="merchantId" placeholder="merchantId" value={form.merchantId} onChange={onChange} />
            <input name="merchantCategory" placeholder="merchantCategory" value={form.merchantCategory} onChange={onChange} />
            <input name="amount" placeholder="amount *" value={form.amount} onChange={onChange} />
            <input name="currency" placeholder="currency" value={form.currency} onChange={onChange} />
            <input name="timestamp" placeholder="timestamp (ISO)" value={form.timestamp} onChange={onChange} />
            <input name="deviceId" placeholder="deviceId" value={form.deviceId} onChange={onChange} />
            <input name="deviceIp" placeholder="deviceIp" value={form.deviceIp} onChange={onChange} />
            <input name="latitude" placeholder="latitude" value={form.latitude} onChange={onChange} />
            <input name="longitude" placeholder="longitude" value={form.longitude} onChange={onChange} />
            <input name="billingCountry" placeholder="billingCountry" value={form.billingCountry} onChange={onChange} />
            <input name="shippingCountry" placeholder="shippingCountry" value={form.shippingCountry} onChange={onChange} />
</div>
        ) : (
          <div><input type="file" accept=".csv" onChange={e=>setFile(e.target.files[0])} /></div>
        )}

        <div style={{marginTop:12}}><button onClick={handlePredict} className="btn">Predict</button></div>
      </div>

      <div className="card" style={{marginTop:12}}>
        <h4>Result</h4>
        <pre>{result? JSON.stringify(result,null,2): 'No result yet'}</pre>
      </div>
    </div>
  )
}